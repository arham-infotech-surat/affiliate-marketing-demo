<?php
class Booking_Modal extends CI_Model {

    

	function __construct() {
			parent::__construct();
			//$this->tbl_testimonial="tbl_testimonial";
			$this->tbl_booking="tbl_booking";
			$this->tbl_appointment="tbl_appointment";
	}





//------------------------ fetch testimonial data -------------------------->

	public function fetch_bookingdata()
	{
		//$this->db->join('tbl_books','tbl_books.book_id = tbl_orders.book_id');
		$this->db->join('customer_tbl','customer_tbl.customer_id = tbl_booking.customer_id');  
		$query = $this->db->get($this->tbl_booking);
		$results=$query->result_array();
		return $results;
	}
	
	public function fetch_appointmentdata()
	{
	    //echo "bjhjv";die;
		//$this->db->join('tbl_books','tbl_books.book_id = tbl_orders.book_id');
		//$this->db->join('customer_tbl','customer_tbl.customer_id = tbl_booking.customer_id');  
		$query = $this->db->get($this->tbl_appointment);
		$results=$query->result_array();
		return $results;
	}

//-------------------------------- End ------------------------------->



//-------------------------------- insert data ------------------------------->

	public function add_book($data)

	{
		$query = $this->db->insert($this->tbl_books,$data);
		return $query;
	}

//-------------------------------- End ------------------------------->



//-------------------------------- testimonial get data ------------------------------->



	public function get_book_data($book_id)
	{
		$query = $this->db->get_where($this->tbl_books,array('book_id' => $book_id));
		//echo $this->db->last_query();die;
		$result = $query->result_array();
		return $result;
	}

//-------------------------------- End ------------------------------->

//-------------------------------- Update ------------------------------->

	public function update_bookdata($data,$book_id)
	{
		$result = $this->db->update($this->tbl_books,$data,array('book_id' => $book_id));
		//echo $this->db->last_query();die;
		return $result;

	}

//-------------------------------- End ------------------------------->

//-------------------------------- delete ------------------------------->

	public function delete_single_booking($booking_id)
	{
		$result = $this->db->delete($this->tbl_booking,array('booking_id' => $booking_id));
		//echo $this->db->last_query();die;
		return $result;
	}
	
	public function delete_single_appoint($appoint_id)
	{
		$result = $this->db->delete($this->tbl_appointment,array('appoint_id' => $appoint_id));
		//echo $this->db->last_query();die;
		return $result;
	}

//-------------------------------- End ------------------------------->



	public function testimonial_MultipleDeleted($delIds){

	if ($delIds) {

        for ($i = 0; $i < count($delIds); $i++)

        {

	        $this->db->where('testimonial_id', $delIds[$i]);

	        $this->db->delete($this->tbl_testimonial);

        }

	}

    redirect('Testimonial/view_testimonial');

	}



}

?>